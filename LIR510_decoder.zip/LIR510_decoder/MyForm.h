#pragma once

#include <stdint.h>
#include <tchar.h>
#include <string>
#include <sstream>


#pragma pack(push, 1)
private union prot
{
	uint8_t data[4];
	struct
	{
		uint32_t A;
	};
};
#pragma pack(pop)

namespace LIR510decoder {


	//using namespace std;

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::TextBox^ textBox3;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::TextBox^ textBox4;


	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::FolderBrowserDialog^ folderBrowserDialog1;


	public:
	uint8_t cnt = 0;
	prot* stin = new prot;
	float grh_in = 0;
	System::Collections::Generic::List<String^> grh_arr;

	private: System::Windows::Forms::CheckBox^ checkBox1;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^ chart1;

	private: System::ComponentModel::BackgroundWorker^ backgroundWorker1;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::Button^ button10;
	private: System::Windows::Forms::Button^ button11;
	public:
		int impulses = 0;

		MyForm(void)
		{
			InitializeComponent();

			findPorts();
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm()
		{
			this->serialPort1->Close();
			this->serialPort1->DataReceived -= gcnew System::IO::Ports::SerialDataReceivedEventHandler(this, &MyForm::DataReceivedHandler);
			delete stin;

			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;


	private: System::IO::Ports::SerialPort^ serialPort1;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::ComboBox^ comboBox2;
	private: System::Windows::Forms::ProgressBar^ progressBar1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;

	private: String^ indata;

	private: System::ComponentModel::IContainer^ components;
	protected:

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea2 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Series^ series2 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->serialPort1 = (gcnew System::IO::Ports::SerialPort(this->components));
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->progressBar1 = (gcnew System::Windows::Forms::ProgressBar());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->folderBrowserDialog1 = (gcnew System::Windows::Forms::FolderBrowserDialog());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->chart1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart1))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(284, 41);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Connect";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(12, 39);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 21);
			this->comboBox1->TabIndex = 5;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox1_SelectedIndexChanged);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(377, 70);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(129, 20);
			this->textBox1->TabIndex = 6;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged_1);
			// 
			// textBox2
			// 
			this->textBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox2->Location = System::Drawing::Point(25, 187);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(253, 35);
			this->textBox2->TabIndex = 7;
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox2_TextChanged);
			// 
			// comboBox2
			// 
			this->comboBox2->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"9600", L"38400", L"115200" });
			this->comboBox2->Location = System::Drawing::Point(145, 39);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(121, 21);
			this->comboBox2->TabIndex = 8;
			// 
			// progressBar1
			// 
			this->progressBar1->Location = System::Drawing::Point(377, 41);
			this->progressBar1->Name = L"progressBar1";
			this->progressBar1->Size = System::Drawing::Size(129, 23);
			this->progressBar1->TabIndex = 9;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(297, 187);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 10;
			this->button2->Text = L"Read";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(284, 66);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 11;
			this->button3->Text = L"Close";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(9, 23);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(64, 13);
			this->label1->TabIndex = 12;
			this->label1->Text = L"COM PORT";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click_1);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(142, 23);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(69, 13);
			this->label2->TabIndex = 13;
			this->label2->Text = L"BAUD RATE";
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(297, 228);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 14;
			this->button4->Text = L"Set impulses";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(141, 228);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(137, 20);
			this->textBox3->TabIndex = 15;
			this->textBox3->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox3_TextChanged);
			// 
			// button5
			// 
			this->button5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button5->Location = System::Drawing::Point(390, 187);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(129, 61);
			this->button5->TabIndex = 16;
			this->button5->Text = L"Start";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(171, 627);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(243, 20);
			this->textBox4->TabIndex = 18;
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(420, 620);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(87, 31);
			this->button6->TabIndex = 19;
			this->button6->Text = L"Save as";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button6_Click);
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Location = System::Drawing::Point(390, 251);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(71, 17);
			this->checkBox1->TabIndex = 20;
			this->checkBox1->Text = L"Auto stop";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &MyForm::checkBox1_CheckedChanged);
			// 
			// chart1
			// 
			chartArea2->Name = L"ChartArea1";
			this->chart1->ChartAreas->Add(chartArea2);
			this->chart1->Location = System::Drawing::Point(12, 274);
			this->chart1->Name = L"chart1";
			series2->ChartArea = L"ChartArea1";
			series2->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Line;
			series2->Name = L"Series1";
			this->chart1->Series->Add(series2);
			this->chart1->Size = System::Drawing::Size(528, 329);
			this->chart1->TabIndex = 21;
			this->chart1->Text = L"chart1";
			this->chart1->Click += gcnew System::EventHandler(this, &MyForm::chart1_Click);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(12, 574);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(55, 29);
			this->button7->TabIndex = 22;
			this->button7->Text = L"Clear";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button7_Click_1);
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(25, 135);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(94, 23);
			this->button8->TabIndex = 23;
			this->button8->Text = L"Reset LIT510";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::button8_Click);
			// 
			// button9
			// 
			this->button9->Location = System::Drawing::Point(125, 135);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(94, 23);
			this->button9->TabIndex = 24;
			this->button9->Text = L"A/0";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm::button9_Click);
			// 
			// button10
			// 
			this->button10->Location = System::Drawing::Point(225, 135);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(94, 23);
			this->button10->TabIndex = 25;
			this->button10->Text = L"�";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &MyForm::button10_Click);
			// 
			// button11
			// 
			this->button11->Location = System::Drawing::Point(325, 135);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(94, 23);
			this->button11->TabIndex = 26;
			this->button11->Text = L"-> 0";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &MyForm::button11_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(534, 662);
			this->Controls->Add(this->button11);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->chart1);
			this->Controls->Add(this->checkBox1);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->progressBar1);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->button1);
			this->Name = L"MyForm";
			this->Text = L"LIR 510 DECODER";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void findPorts() {
		array<Object^>^ objectArray = serialPort1->GetPortNames();
		this->comboBox1->Items->AddRange(objectArray);
	}

	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void listBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		// add sender name
		this->textBox2->Text = String::Empty;
		if (this->comboBox1->Text == String::Empty || this->comboBox2->Text == String::Empty)
			this->textBox1->Text = "Please Select Port Settings";
		else {
			try {
				// make sure port isn't open	
				if (!this->serialPort1->IsOpen) {
					this->serialPort1->PortName = this->comboBox1->Text;
					//this->textBox1->Text=this->comboBox1->Text;
					this->serialPort1->BaudRate = Int32::Parse(this->comboBox2->Text);
					//this->textBox1->Text=this->comboBox2->Text;
					//this->textBox1->Text = "Enter Message Here";
					//this->serialPort1->RtsEnable = true;

					//this->serialPort1->DataReceived += gcnew System::IO::Ports::SerialDataReceivedEventHandler(this, &MyForm::DataReceivedHandler);

					this->serialPort1->Open();
					//open serial port 
					this->progressBar1->Value = 100;

					this->textBox1->Text = "Port Opened";
				}
				else
					this->textBox1->Text = "Port Is already Openned";
			}
			catch (UnauthorizedAccessException^) {
				this->textBox1->Text = "UnauthorizedAccess";
			}


		}
	}

	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
		// check if port is ready for reading
		if (this->serialPort1->IsOpen) {
			// Reset the text in the result label.
			this->textBox2->Text = String::Empty;

			bool _continue = true;

			// this will read manually
				this->serialPort1->DataReceived += gcnew System::IO::Ports::SerialDataReceivedEventHandler(this, &MyForm::DataReceivedHandler);
			try {
				//this->textBox2->Text = this->serialPort1->ReadLine();
			}
			catch (TimeoutException^) {
				this->textBox2->Text = "Timeout Exception";
			}

			// Disable the init button
			// the asynchronous operation is done.
			this->button2->Enabled = false;

			//this->ovalShape1->FillColor = Color::Green;

		}
		else
			// give error warning
			this->textBox2->Text = "Port Not Opened";
	}

	private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
		//close serialPort
		this->serialPort1->Close();
		// update progress bar
		this->progressBar1->Value = 0;
		// Enable read button
		this->button2->Enabled = true;
		// Enable the init button
		this->button3->Enabled = true;

		this->serialPort1->DataReceived -= gcnew System::IO::Ports::SerialDataReceivedEventHandler(this, &MyForm::DataReceivedHandler);

		this->textBox1->Text = "Port Closed";

	}
	private: System::Void textBox2_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox1_TextChanged_1(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void DataReceivedHandler(System::Object^ sender, System::IO::Ports::SerialDataReceivedEventArgs^ e)
	{
		System::IO::Ports::SerialPort^ sp = (System::IO::Ports::SerialPort^)sender;
		bool check = 0;
		int temp = 0;
		while (1){
			if (this->serialPort1->IsOpen)
				temp = sp->ReadByte();
			if (temp == 10) {
				cnt = 0;
				check = 1;
			}else if (temp == 11 && check) {
				int teemp = stin->A;
				check = 0;
				indata = gcnew String(convert_str(teemp).c_str()); //teemp.ToString(); //gcnew System::String(q.c_str());
				grh_arr.Add(indata);
				this->Invoke(gcnew Action(this, &MyForm::SetTextToTextBox));
				this->Invoke(gcnew Action(this, &MyForm::SetChart));
				break;
			} else {
				stin->data[cnt] = temp;
				cnt++;
				continue;
			}
		}

		/*
		String^ outdata;
		outdata = "0";
		sp->Write(outdata);
		*/
	}

	void SetTextToTextBox(){
		if (!this->textBox2->IsDisposed)
			this->textBox2->Text = "h: " + indata;
	}

	void SetChart() {
		chart1->Series[0]->Points->Add(grh_in);
		if (chart1->Series[0]->Points->Count > 200) {
			chart1->Series[0]->Points->RemoveAt(0);
			chart1->ResetAutoValues();
		}
	}

	std::string convert_str(int num) {

		using namespace std;

		std::ostringstream strnum;
		strnum << std::hex << num;
		std::string result = strnum.str();

		//check negative
		int temp = std::stoi(result);
		if (temp > 90000000) temp = -100000000 + temp;

		if (temp < 0 && temp > -9999) {
			temp *= -1;
			result = std::to_string(abs(temp));

			while (result.length() < 5) result.insert(0, "0");
			result.insert(result.length() - 4, ".");
			result.insert(result.length() - 6, "-");

		}
		else {
			result = std::to_string(temp);
			while (result.length() < 5) result.insert(0, "0");
			result.insert(result.length() - 4, ".");
		}
		grh_in = (float)temp/10000;
		return result;
	}


	private: System::Void label1_Click_1(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	if(textBox3->Text != "")
		impulses = Int32::Parse(textBox3->Text);
}
private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
	this->button5->Text = this->button5->Text =="Start" ? "Stop" : "Start";
}
private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->folderBrowserDialog1->ShowDialog() == Windows::Forms::DialogResult::OK) {
		String^ file_name = folderBrowserDialog1->SelectedPath;
		textBox4->Text = file_name;
	}
}

private: System::Void textBox3_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void checkBox1_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void chart1_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void listBox1_SelectedIndexChanged_1(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button7_Click_1(System::Object^ sender, System::EventArgs^ e) {
	chart1->Series[0]->Points->Clear();

}

private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->serialPort1->IsOpen)
		this->serialPort1->Write("9");
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->serialPort1->IsOpen)
		this->serialPort1->Write("3");
}
private: System::Void button10_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->serialPort1->IsOpen)
		this->serialPort1->Write("6");
}
private: System::Void button11_Click(System::Object^ sender, System::EventArgs^ e) {
	if (this->serialPort1->IsOpen)
		this->serialPort1->Write("0");
}
};
}
